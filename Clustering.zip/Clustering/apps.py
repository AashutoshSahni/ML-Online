from django.apps import AppConfig


class ClusteringConfig(AppConfig):
    name = 'Clustering'
