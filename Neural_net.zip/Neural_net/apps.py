from django.apps import AppConfig


class NeuralNetConfig(AppConfig):
    name = 'Neural_net'
