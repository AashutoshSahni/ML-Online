from django.apps import AppConfig


class RegressionConfig(AppConfig):
    name = 'Regression'
